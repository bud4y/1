import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingPageComponent } from './component/landing-page/landing-page.component';
import { PipelinePremiumComponent } from './component/pipeline-premium/pipeline-premium.component';
import { UnearnedPremiumReserveComponent } from './component/unearned-premium-reserve/unearned-premium-reserve.component';
import { DragDropUploadFileDirective } from './component/drag-drop-upload-file.directive';

@NgModule({
  declarations: [
    AppComponent,
    LandingPageComponent,
    PipelinePremiumComponent,
    UnearnedPremiumReserveComponent,
    DragDropUploadFileDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
