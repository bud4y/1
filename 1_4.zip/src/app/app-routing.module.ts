import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './component/landing-page/landing-page.component';
import { PipelinePremiumComponent } from './component/pipeline-premium/pipeline-premium.component';
import { UnearnedPremiumReserveComponent } from './component/unearned-premium-reserve/unearned-premium-reserve.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/main/pipeline-premium',
    pathMatch: "full"
  },
  {
    path: "main",
    component: LandingPageComponent,
    children: [
      {
        path: "pipeline-premium",
        component: PipelinePremiumComponent
      },
      {
        path: "unearned-premium-reserve",
        component: UnearnedPremiumReserveComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
