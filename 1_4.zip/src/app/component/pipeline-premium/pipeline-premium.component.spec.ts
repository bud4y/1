import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PipelinePremiumComponent } from './pipeline-premium.component';

describe('PipelinePremiumComponent', () => {
  let component: PipelinePremiumComponent;
  let fixture: ComponentFixture<PipelinePremiumComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PipelinePremiumComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelinePremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
