import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-pipeline-premium',
  templateUrl: './pipeline-premium.component.html',
  styleUrls: ['./pipeline-premium.component.scss']
})
export class PipelinePremiumComponent implements OnInit {

  displayOptions: boolean = true;
  progress: boolean = false;
  msg: string = "your file ";
  fileArr: Array<any> = [];
  fileObject: Array<any> = [];
  form: FormGroup;
  constructor(public fb: FormBuilder,
    private sanitizer: DomSanitizer,) {
    this.form = this.fb.group({
      avatar: [null]
    })
  }

  ngOnInit(): void {
  }

  uploadFile() {
    this.displayOptions = !this.displayOptions;


  }
  upload(e: any) {
    console.log("upload : ", e);
    console.log(e[0]?.type);
    const fileListAsArray = Array.from(e);
    fileListAsArray.forEach((item, i) => {
      let fileElemArr: any = (e as HTMLInputElement);
      console.log("file ", fileElemArr)
      const url = URL.createObjectURL(fileElemArr[i]);
      //this.imgArr.push(url);
      this.fileArr.push({ item, url: url });
      console.log("file arr : ", this.fileArr)
    });
    this.fileArr.forEach((item) => {
      this.fileObject.push(item.item)
    })
  }
  sanitize(url: string) {
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }
}
