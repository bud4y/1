import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {

  constructor() { }
  tabId: number = 1;
  ngOnInit(): void {
  }

  tabClicked(id: number) {
    console.log(id);
    this.tabId = id;
  }
}
