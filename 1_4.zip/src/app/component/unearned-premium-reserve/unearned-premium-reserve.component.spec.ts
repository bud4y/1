import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnearnedPremiumReserveComponent } from './unearned-premium-reserve.component';

describe('UnearnedPremiumReserveComponent', () => {
  let component: UnearnedPremiumReserveComponent;
  let fixture: ComponentFixture<UnearnedPremiumReserveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnearnedPremiumReserveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnearnedPremiumReserveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
