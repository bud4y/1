import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unearned-premium-reserve',
  templateUrl: './unearned-premium-reserve.component.html',
  styleUrls: ['./unearned-premium-reserve.component.scss']
})
export class UnearnedPremiumReserveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
