import { DragDropUploadFileDirective } from './drag-drop-upload-file.directive';

describe('DragDropUploadFileDirective', () => {
  it('should create an instance', () => {
    const directive = new DragDropUploadFileDirective();
    expect(directive).toBeTruthy();
  });
});
